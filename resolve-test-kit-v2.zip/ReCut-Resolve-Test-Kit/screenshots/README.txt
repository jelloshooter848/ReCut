Put your screenshots here (named after the check, e.g. F13-inspector.png).
