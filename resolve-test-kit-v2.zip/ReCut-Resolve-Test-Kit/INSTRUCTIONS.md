# INSTRUCTIONS — test ReCut's timeline exports in DaVinci Resolve

You are testing whether three timeline files written by **ReCut** (a video editor; you do not need to know it) open correctly in **DaVinci Resolve** on this Mac. The files describe the same short edit (00:00:15:00 long) in three formats: **FCPXML**, **OpenTimelineIO (OTIO)** and **CMX3600 EDL**. You import each one into Resolve, compare what Resolve shows with `EXPECTED.md`, and write the outcome into `RESULTS.md` using the check ids (F1, O1, E1, …). The media is synthetic: every video frame shows its own file name, source frame number and source timecode, so you can read positions straight off the picture.

## Rules

1. Do not edit anything in Resolve to make a check pass (no moving, trimming, retiming). Only the relinking steps described here are allowed; if you needed one, say so.
2. Record what you **observe**, with values. "FAIL" without the observed value is not useful.
3. Quote every error or warning dialog verbatim (or screenshot it).
4. Items in an "EXPECTED.md › Not carried" list are known format limits: mark them NOTE, not FAIL.
5. Use a **new Resolve project for each format** (so one import cannot reuse media another import already linked).
6. When you are not sure how to do something in your Resolve version, use the closest equivalent and say what you did.

## Kit contents

| Path | What |
|---|---|
| `INSTRUCTIONS.md` | this file |
| `EXPECTED.md` | the expected result of every check, generated from ReCut's data |
| `RESULTS.md` | the form you fill in |
| `localize.sh` | points the files at this folder (run once, Setup step 3) |
| `media/` | the synthetic media (do not rename or move) |
| `exports/` | the timeline files to import |
| `project/ReCut-Resolve-Test.recut` | the ReCut project (only for optional Part B) |
| `screenshots/` | put your screenshots here |

## Setup

1. **Record the environment** in RESULTS.md: Resolve version and edition (DaVinci Resolve menu › About DaVinci Resolve), macOS version (Apple menu › About This Mac), Mac chip (same window: "Chip Apple M…" or "Processor … Intel").
2. **Unzip** the kit so that the folder is exactly `~/Desktop/ReCut-Resolve-Test-Kit` (double-click the zip in Finder; it creates the folder `ReCut-Resolve-Test-Kit`; move it to the Desktop if needed). Use a path **without spaces**. If the Desktop is synced to iCloud with "Optimise Mac Storage", use `~/ReCut-Resolve-Test-Kit` instead and adjust the paths below.
3. **Localize the paths.** The files in `exports/` and `project/` refer to the media through a placeholder (`/RECUT_KIT_ROOT`). Open **Terminal** (Applications › Utilities › Terminal) and run:

   ```
   cd ~/Desktop/ReCut-Resolve-Test-Kit
   sh localize.sh
   ```

   It must end with `localize.sh: OK` and list the 7 media files as found. Paste its output into **S1**. (It is safe to run again, e.g. after moving the folder: it always starts from the original files, kept in `_originals/`.)
4. **Resolve preference (once):** DaVinci Resolve menu › Preferences › **User** › **Editing** › New Timeline Settings › **Start Timecode** = `00:00:00:00` › Save. (This makes new timelines start at 00:00:00:00 like EXPECTED.md. If an imported timeline still starts at 01:00:00:00, keep it and add one hour to every record timecode in EXPECTED.md; note it in F3/O3.)
5. **Per format, a new project** (Project Manager › New Project; names below). **Before importing anything**, open File › Project Settings… › **Master Settings**:
   - Timeline resolution: **1280 x 720 HD 720P**
   - Timeline frame rate: **23.976** frames per second (for the optional drop-frame part: **29.97** and tick **Use drop frame timecode**)
   - Playback frame rate: same as the timeline frame rate
   - then **Image Scaling** › Input Scaling › Mismatched resolution files: **Scale entire image to fit** (the default)
   - Save. Record in **S2** what you set (and anything you could not set).
6. **Edit page layout:** switch to the **Edit** page (bottom bar). Open the **Edit Index** (button "Edit Index" at the top left of the Edit page, or Workspace › … if your version moved it); in its ⋯ options make sure both video and audio tracks are listed and, if available, markers. The Edit Index lists every clip with **Record In / Record Out** and **Source In / Source Out**: that is the main tool for F5/F6. Open the **Inspector** (top right). In the timeline view options (the small icon above the track headers) turn on audio waveforms and clip names.
7. **Moving the playhead to a timecode:** click once on an empty part of the timeline ruler area so the timeline has focus, then type the digits of the timecode without separators and press Return, e.g. type `00000412` for 00:00:04:12 (`01000412` if the timeline starts at 01:00:00:00). Check the timecode display above the viewer shows the right value. The arrow keys step one frame.
8. **Screenshots:** in Terminal, `screencapture -T 5 ~/Desktop/ReCut-Resolve-Test-Kit/screenshots/F-timeline.png` takes a full-screen shot after 5 seconds (bring Resolve to the front meanwhile). Or press ⇧⌘3 (full screen, saved on the Desktop) and move the file into `screenshots/`. Name screenshots after the check: `F4-timeline.png`, `F13-inspector.png`, … Required screenshots are listed per part; add more whenever something fails.

## Part A1 — FCPXML

Project name **RT-FCPXML** (23.976, Setup step 5).

1. File › Import › **Timeline…** (in older versions: File › Import Timeline › Import AAF, EDL, XML…). Choose `exports/Resolve Test.fcpxml`.
2. In the import dialog: tick **Automatically import source clips into media pool**; keep **Use sizing information** ticked (needed for F13/F14); leave other options at their defaults (if there is "Automatically set project settings", leave it as it is and say in F1 whether it changed anything). OK.
3. If Resolve asks where the media is, choose the kit's `media` folder, and note that it asked (F2).

Checks (expected values: EXPECTED.md › FCPXML):

- **F1** The import finishes; note every dialog/warning text. The new timeline opens (double-click it in the Media Pool if not).
- **F2** No clip shows "Media Offline" (red). The Media Pool contains A_Red.mp4, B_Blue.mp4, C_Green.mp4, D_Purple.mp4, Music_Pulse.wav, V2_Still.png (and the timeline). Right-click a clip › Reveal in Media Pool / Clip Attributes shows a path inside the kit's `media` folder.
- **F3** Timeline name, resolution, frame rate and **start timecode** (the timecode at the first frame; right-click the timeline in the Media Pool › Timelines › Starting Timecode… shows it).
- **F4** Track list: which V and A tracks hold which clips (EXPECTED › F4). Screenshot the whole timeline zoomed to fit (⇧Z): `F4-timeline.png`.
- **F5** For every clip in EXPECTED › F5/F6, the Record In and Record Out in the Edit Index (or the clip's position on the timeline) match to the frame. Screenshot the Edit Index: `F5-edit-index.png`. List every mismatch.
- **F6** Source In of every clip matches (Edit Index › Source In). Then, for every video clip with a check frame, park the playhead at the check frame and read the burned-in label (FRAME and TC) in the viewer; it must equal the table. Screenshot one of them (`F6-label.png`).
- **F7** The gap on V1 (EXPECTED › F7): black picture.
- **F8** Fade from black at the start: the first frames go from black to full picture (step through the first 12 frames). Note whether Resolve shows it as Opacity keyframes (expected for FCPXML) or as a transition.
- **F9** Cross Dissolve on V1: a transition of the expected length centred on the expected cut. Click it and read its duration in the Inspector. Screenshot `F9-dissolve.png`.
- **F10** Dip to Black: the picture fades out to black before the cut; after the cut V3 covers V1, so check the fade-in as Opacity keyframes on the clip (expected for FCPXML: Opacity keyframes on the two clips, not a transition object).
- **F11** 200% clip: the speed shown (Inspector or right-click › Change Clip Speed) and the two label readings given in EXPECTED › F11.
- **F12** Disabled clip: present at the expected place, shown disabled, black picture.
- **F13** V2 still: select it, Inspector › Video: Zoom, Position, Rotation Angle, Opacity, Cropping (EXPECTED › F13 table) and the picture (park at 00:00:01:12). Screenshot the Inspector and the viewer: `F13-inspector.png`. Read the "Picture" paragraph in EXPECTED › F13 carefully: the picture decides a sign question.
- **F14** V2 keyframed clip: keyframe diamonds on Position and Zoom (Inspector, or the clip's keyframe track), and the values at the three playhead positions in EXPECTED › F14. Screenshot `F14-keyframes.png`.
- **F15** Compound clip content on V3 and its sound (one copy) with the expected range and source.
- **F16** Audio not doubled: list the audio items per file and time (EXPECTED › F4 / F16). A second audible copy of a clip's audio is a FAIL; the silent extras listed in F4 are expected.
- **F17** Audio cross fade between the B_Blue and C_Green sound (EXPECTED › transitions list): present, length.
- **F18** Music: select it, Inspector › Audio › Volume, and the fade handles on the clip (length of fade in / out). Screenshot `F18-music.png`.
- **F19** Markers: names, positions, colours, notes, and whether they sit on the ruler or on a clip.
- **F20** Play the whole timeline once from the start (space bar). Note stutters, errors, or "Media Offline" frames.

## Part A2 — OpenTimelineIO

Project name **RT-OTIO** (23.976, Setup step 5). Needs Resolve 18.5 or later; if the import menu cannot open `.otio` files, mark O1 FAIL with the message and skip the rest of A2.

1. File › Import › **Timeline…**, choose `exports/Resolve Test.otio`. Tick **Automatically import source clips into media pool** if offered. OK.

Checks **O1–O20** are the same as F1–F20, with the expected values in EXPECTED › OpenTimelineIO. Differences to expect (not bugs): the V2 still is full frame and opaque (O13), the V2 clip is not animated (O14), the Dip to Black is a plain cut (O10), the music has no level change or fades (O18), markers have colours. Screenshots: `O4-timeline.png`, `O5-edit-index.png`, `O13-viewer.png`.

## Part A3 — EDL (three files)

Project name **RT-EDL** (23.976, Setup step 5). An EDL holds one video track, so there is one file per ReCut video track; import each as its own timeline.

1. File › Import › **Timeline…**, choose `exports/Resolve Test_V1.edl`.
2. In the import dialog: tick **Automatically import source clips into media pool**; when Resolve asks for the location of the source clips, choose the kit's `media` folder. Keep the frame rate 23.976 if asked. OK.
3. **If clips come in offline** (red): this is E1 information, record it. Then try, in this order, and record which one worked: (a) select the timeline in the Media Pool, right-click › Timelines › **Relink Clips for Selected Timeline…** (or Relink Selected Clips) and point at the `media` folder; (b) start a new project, first import the media (File › Import › Media…, select all files in `media`), then import the EDL with "Automatically import source clips" **un**ticked.
4. Repeat steps 1–2 for `exports/Resolve Test_V2.edl` and `exports/Resolve Test_V3.edl` (each makes a new timeline).

Checks (EXPECTED › EDL):

- **E1** Import of the _V1 EDL: dialogs, and how the media got linked (automatically / after relink a / route b).
- **E2** V1 events: Record In / Out per clip (Edit Index). Screenshot `E2-edit-index.png`.
- **E3** Source In per clip and the burned-in labels at the check frames.
- **E4** Fade from black at the start (12 frames).
- **E5** Cross Dissolve of 24 frames (cut point at its start or centre: both fine).
- **E6** Dip to Black: dissolve to black then from black, black frame at the cut.
- **E7** 200% speed of the C_Green clip, and the label readings.
- **E8** The disabled clip is absent; the timeline ends where EXPECTED says.
- **E9** Audio: A1 has one clip under each video clip (same ranges); no music; nothing doubled.
- **E10** Markers from the `* LOC:` lines (present or not).
- **E11** The _V2 timeline: two clips, full frame, positions and sources as listed (the still may need relinking or fail: note).
- **E12** The _V3 timeline: one D_Purple clip, positions and source; where its audio went (channel 3).

## Optional — 29.97 drop-frame

Only if time allows. New project **RT-DF** with Timeline frame rate **29.97** and **Use drop frame timecode** ticked (Setup step 5), timeline start 00:00:00:00.

- **D1** Import `exports/Resolve Test DF.fcpxml` as in A1. Check the clip table, the dissolve and the marker in EXPECTED › 29.97 drop-frame; timecodes must show `;` and the marker sits at 00:01:00;02. Check the labels at the check frames.
- **D2** Same with `exports/Resolve Test DF.otio`, in a fresh project RT-DF-OTIO with the same settings.
- **D3** Same with `exports/Resolve Test DF_V1.edl`, in a fresh project RT-DF-EDL, imported as in A3.

## Optional Part B — ReCut app exports

This tests the app's own Export Timeline dialog and save path. It needs a GitHub login.

1. **B1** Open https://github.com/jelloshooter848/ReCut/actions/runs/37830806574 (logged in to GitHub). Under **Artifacts**, download **ReCut-macos-arm64** (Apple silicon Mac) or **ReCut-macos-x64** (Intel Mac). Unzip it: it contains a `.dmg`. Open the dmg and drag ReCut to Applications; start ReCut from Applications (it is signed and notarized, so it should open without a security warning; if macOS blocks it, record the exact message and use System Settings › Privacy & Security › Open Anyway). Record the version shown in ReCut's About window.
2. **B2** In ReCut: File › Open Project…, choose `project/ReCut-Resolve-Test.recut` in the kit (after localize.sh). It should open without asking to relink; the media list shows 7 files, none offline. If ReCut asks to relink, point it at the kit's `media` folder and say so.
3. Make a folder `appexports` in the kit (Finder, or `mkdir ~/Desktop/ReCut-Resolve-Test-Kit/appexports` in Terminal).
4. **B3** File › **Export Timeline…**: Sequence **Resolve Test**, Format **FCPXML**. Compare the report line and the two issue lists with EXPECTED › Optional Part B and the FCPXML "Not carried" list. Screenshot the dialog (`B3-dialog.png`). Export… and save with the default name into `appexports`. Note the toast.
5. **B4** Same with Format **OpenTimelineIO**.
6. **B5** Same with Format **CMX3600 EDL** (the name you type is the base name; it writes `Resolve Test_V1.edl`, `Resolve Test_V2.edl`, `Resolve Test_V3.edl`).
7. **B6** In Terminal: `cd ~/Desktop/ReCut-Resolve-Test-Kit && diff -r exports appexports`. Expected: only lines like "Only in exports: Resolve Test DF…" (the drop-frame files you did not export) and "Only in exports: Resolve Test_V1-reels.edl" (an experiment, see RETEST.md), no "differ" lines. Paste any other output.
8. **B7** New Resolve project **RT-APP** (23.976), import `appexports/Resolve Test.fcpxml` as in A1 and spot-check F5 (Edit Index) and F13 (still Inspector). Any difference from A1 is a FAIL.

## Results

1. Fill in every row of `RESULTS.md` (and the Environment table).
2. Make sure the screenshots are in `screenshots/` and named after their checks.
3. Zip the results: in Terminal `cd ~/Desktop && zip -r ReCut-Resolve-Results.zip ReCut-Resolve-Test-Kit/RESULTS.md ReCut-Resolve-Test-Kit/screenshots`.
4. Give `ReCut-Resolve-Results.zip` (or at least the text of RESULTS.md) back to the person who gave you this kit.
