# EXPECTED — what Resolve should show

Generated from ReCut's own export data (the same code that wrote the files in `exports/`). Check ids (F…, O…, E…, D…, B…) are the ones in INSTRUCTIONS.md and RESULTS.md.

## How to read this file

- **Timecodes** are timeline timecodes with the timeline starting at **00:00:00:00**. If your Resolve timeline starts at 01:00:00:00, add one hour to every *record* timecode (00:00:08:00 becomes 01:00:08:00). *Source* timecodes never change: every media file starts at 00:00:00:00 (since kit v2 the video files also carry an embedded start timecode of 00:00:00:00, which Resolve shows as the clip's Start TC).
- At 23.976 fps timecode counts 24 frames per second (00:00:01:00 = frame 24). The sequence is 360 frames = 00:00:15:00.
- **Record Out is exclusive**: it is the first frame *after* the clip (the next clip's Record In), which is how Resolve's Edit Index shows it too. "Frames" is the clip's length.
- **Source In** is the clip's first source frame. Every video file has its source frame number and source timecode burned into the picture (top-left: `FRAME 0123` and `TC 00:00:05:03`; bottom row: file name, frame and timecode). The first frame of a clip shows its Source In. Because the first frames of some clips are under a dissolve or fade, the last column gives a **check frame**: park the playhead on that record timecode and the label must read exactly the given FRAME number (and TC).
- Every video file also has a thin light crosshair through the frame centre (x 640, y 360), to help judge positions.
- Things listed under **Not carried** are known limits of that format. They are not bugs: report what you see, but mark them NOTE, not FAIL.

## The media (`media/`)

| File | Format | How to recognise it |
|---|---|---|
| A_Red.mp4 | H.264 1280×720 23.976 fps + AAC stereo, 20.00 s | dark red background, 440 Hz tone |
| B_Blue.mp4 | H.264 1280×720 23.976 fps + AAC stereo, 20.00 s | dark blue background, 660 Hz tone (quieter) |
| C_Green.mp4 | H.264 1280×720 23.976 fps + AAC stereo, 20.00 s | dark green background, 880 Hz tone (louder) |
| D_Purple.mp4 | H.264 1280×720 23.976 fps + AAC stereo, 20.00 s | purple background, 1100 Hz tone |
| E_NTSC_2997.mp4 | H.264 1280×720 29.970 fps + AAC stereo, 66.00 s | brown background, 550 Hz tone, drop-frame timecode label |
| Music_Pulse.wav | WAV 2 ch 48000 Hz, 16.00 s | 330 Hz pulses, 4 per second (on/off every 0.25 s): a comb-like waveform |
| V2_Still.png | PNG still 640×360 | yellow card, black border and crosshair, red square at its centre, "V2 STILL" and "TOP" along its top edge |

## The ReCut sequence "Resolve Test" (what was exported)

1280×720, 23.976 fps, 360 frames (00:00:15:00). Built in ReCut with: clips on V1 with linked audio on A1 and one gap; a fade from black at the start; a Cross Dissolve and a Dip to Black; a 200% speed clip; a disabled clip at the end; on V2 a still moved, scaled, rotated and at 70% opacity plus a clip with linear position and scale keyframes; a compound (nested) clip; music on A2 with −6 dB gain and fades; an audio cross fade on A1; a marker and a chapter marker. Compound clips do not exist in these formats: the export flattens the compound clip into its contents, which get their own tracks ("V2 (2)" → Resolve V3, "A2 (2)" → Resolve A3).

---

## FCPXML — `exports/Resolve Test.fcpxml`

### F3 Timeline
- Name "Resolve Test", 1280×720, 23.976 fps, non-drop-frame, length 360 frames (00:00:15:00). The FCPXML says the timeline starts at 00:00:00:00 (`tcStart="0s"`).

### F4 Tracks
Video tracks:

| Resolve track | ReCut track (after flattening) | Clips | Files, in order | Note |
|---|---|---|---|---|
| V1 | V1 | 5 | A_Red.mp4, B_Blue.mp4, C_Green.mp4, A_Red.mp4, B_Blue.mp4 (disabled) |  |
| V2 | V2 | 2 | V2_Still.png, D_Purple.mp4 |  |
| V3 | V2 (2) | 1 | D_Purple.mp4 | contents of the compound clip |

Exactly 3 video tracks hold clips. **Audio:** FCPXML has no audio track numbers. Each linked video + audio pair (the V1 clips and the compound clip's contents) is **one** FCPXML clip carrying picture and sound, so Resolve places its sound under the picture on an audio track it chooses, linked to the picture; the music is a separate audio-only clip. Expected audio items, **each exactly once**, on any audio track:

- A_Red.mp4 00:00:00:00–00:00:03:00 (sound of the V1 clip)
- B_Blue.mp4 00:00:04:00–00:00:08:00 (sound of the V1 clip)
- C_Green.mp4 00:00:08:00–00:00:11:00 (sound of the V1 clip)
- A_Red.mp4 00:00:11:00–00:00:14:00 (sound of the V1 clip)
- Music_Pulse.wav 00:00:00:00–00:00:11:00 (audio-only clip)
- D_Purple.mp4 00:00:11:00–00:00:13:00 (sound of the V3 clip)

Expected **extra** audio items (not a FAIL): Resolve ignores FCPXML's "video only" mark, so a video-only clip of a file with sound brings its sound too; ReCut writes it at −96 dB (silent):

- B_Blue.mp4 00:00:14:00–00:00:15:00 (sound of the V1 clip, disabled), Volume −96 dB (Resolve may show its minimum)
- D_Purple.mp4 00:00:05:00–00:00:08:00 (sound of the V2 clip), Volume −96 dB (Resolve may show its minimum)

Resolve may add empty tracks; that is fine, note it. The track numbers of the audio items do not matter; their times, files and count do.

### F5 / F6 Clips
| # | Track | File | Record In | Record Out | Frames | Source In (= burned-in label on the clip's first frame) | Speed | Enabled | Burned-in label check (park the playhead here) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | V1 | A_Red.mp4 | 00:00:00:00 | 00:00:03:00 | 72 | 00:00:02:00 (frame 48) | 100% | yes | at **00:00:00:12** → FRAME **0060**, TC 00:00:02:12 |
| 2 | V1 | B_Blue.mp4 | 00:00:04:00 | 00:00:08:00 | 96 | 00:00:05:00 (frame 120) | 100% | yes | at **00:00:04:00** → FRAME **0120**, TC 00:00:05:00 |
| 3 | V1 | C_Green.mp4 | 00:00:08:00 | 00:00:11:00 | 72 | 00:00:10:00 (frame 240) | 200% | yes | at **00:00:08:12** → FRAME **0264**, TC 00:00:11:00 |
| 4 | V1 | A_Red.mp4 | 00:00:11:00 | 00:00:14:00 | 72 | 00:00:12:12 (frame 300) | 100% | yes | at **00:00:13:00** → FRAME **0348**, TC 00:00:14:12 |
| 5 | V1 | B_Blue.mp4 | 00:00:14:00 | 00:00:15:00 | 24 | 00:00:16:16 (frame 400) | 100% | **no** | disabled: viewer shows what is below it (black) |
| 6 | V2 | V2_Still.png | 00:00:01:00 | 00:00:03:00 | 48 | — | — | yes | still image (no label) |
| 7 | V2 | D_Purple.mp4 | 00:00:05:00 | 00:00:08:00 | 72 | 00:00:01:00 (frame 24) | 100% | yes | at **00:00:05:00** → FRAME **0024**, TC 00:00:01:00 (the picture is small here: zoom into the viewer) |
| 8 | V3 | D_Purple.mp4 | 00:00:11:00 | 00:00:13:00 | 48 | 00:00:13:12 (frame 324) | 100% | yes | at **00:00:11:00** → FRAME **0324**, TC 00:00:13:12 |
| 9 | A1 | A_Red.mp4 | 00:00:00:00 | 00:00:03:00 | 72 | 00:00:02:00 (frame 48) | 100% | yes | (audio) |
| 10 | A1 | B_Blue.mp4 | 00:00:04:00 | 00:00:08:00 | 96 | 00:00:05:00 (frame 120) | 100% | yes | (audio) |
| 11 | A1 | C_Green.mp4 | 00:00:08:00 | 00:00:11:00 | 72 | 00:00:10:00 (frame 240) | 200% | yes | (audio) |
| 12 | A1 | A_Red.mp4 | 00:00:11:00 | 00:00:14:00 | 72 | 00:00:12:12 (frame 300) | 100% | yes | (audio) |
| 13 | A2 | Music_Pulse.wav | 00:00:00:00 | 00:00:11:00 | 264 | 00:00:00:00 (frame 0) | 100% | yes | (audio) |
| 14 | A3 | D_Purple.mp4 | 00:00:11:00 | 00:00:13:00 | 48 | 00:00:13:12 (frame 324) | 100% | yes | (audio) |

- Audio clips have no picture: check their Record In / Out and file in the Edit Index (or by hovering / selecting them).
- The "Track" column gives ReCut's track; for audio, Resolve's track number may differ (see F4).
- Each linked V1 clip and its sound are one FCPXML clip: in Resolve the audio should sit under its picture and be linked to it (selecting the picture selects the sound).

### F7 Gap
- V1 is empty from 00:00:03:00 to 00:00:04:00 (24 frames): the viewer is black there and only the music plays (A1 is empty there too).

### F8–F10, F17 Transitions
- V1: **fade from black**, 12 frames, 00:00:00:00 to 00:00:00:12 on A_Red.mp4, as Opacity keyframes on the clip (Inspector › Composite › Opacity: 0 at the clip start, 100 at the end of the fade), not as a transition. Viewer: 00:00:00:00 is black, 00:00:00:06 is about half brightness, 00:00:00:12 is full brightness.
- V1: **Cross Dissolve**, 24 frames, centred on the cut at 00:00:08:00 (from 00:00:07:12 to 00:00:08:12), B_Blue.mp4 → C_Green.mp4.
- V1: **Dip to Black**, 12 frames centred on the cut at 00:00:11:00, C_Green.mp4 → A_Red.mp4, as Opacity keyframes: C_Green.mp4 fades 100 → 0 from 00:00:10:18 to 00:00:11:00, A_Red.mp4 fades 0 → 100 from 00:00:11:00 to 00:00:11:06 (no transition object). Viewer: C_Green.mp4 darkens from 00:00:10:18 to nearly black at 00:00:10:23 (judge this fade-out half). From 00:00:11:00 the V3 clip (D_Purple.mp4, full frame) covers V1, so the frame at 00:00:11:00 and the fade-in half are **not** visible in the viewer: check the fade-in only as Opacity keyframes on the A_Red.mp4 clip.
- Audio of B_Blue.mp4 → C_Green.mp4 (A1 in ReCut, under V1): **audio cross fade with the picture's Cross Dissolve**, **24 frames**, 00:00:07:12 to 00:00:08:12. In ReCut it was 12 frames (00:00:07:18–00:00:08:06): FCPXML carries linked video and audio as one clip, so one transition (with a video and an audio filter) covers both and the audio takes the video length. Resolve may show it as an audio transition of 24 frames on the audio track, or as part of the video transition: say which.

### F11 Speed
- C_Green.mp4 on V1 (00:00:08:00–00:00:11:00): speed **200%** (Inspector › Speed Change, or right-click › Change Clip Speed). Its picture advances 2 source frames per timeline frame: at 00:00:08:12 the label reads FRAME 264, at 00:00:09:00 it reads FRAME 288 (12 timeline frames later, 24 source frames later). Its audio on A1 is also 200% (higher pitch or a faster pulse, depending on Resolve's pitch setting).

### F12 Disabled clip
- B_Blue.mp4 on V1 at 00:00:14:00–00:00:15:00 is present but **disabled** (greyed out); the viewer is black there. It has no audio clip in ReCut; from FCPXML Resolve also brings in its sound, disabled and at −96 dB (expected, see F4).

### F13 V2 still (Inspector)
Select the V2 clip V2_Still.png (00:00:01:00–00:00:03:00) and open the Inspector (Video tab):

| Inspector field | Expected | Derived from |
|---|---|---|
| Transform › Zoom X / Zoom Y | **0.500 / 0.500** | `scale="0.5 0.5"`: 50% of the fitted size |
| Transform › Position X | **192.000** | `position="26.666667 15"`: FCPXML position is in percent of the frame **height** (720 px), so 26.666667 × 720 / 100 = 192 px right of centre |
| Transform › Position Y | **108.000** | 15 × 720 / 100 = 108 px; FCPXML and Resolve both count +Y **up**, so this is 108 px above centre |
| Transform › Rotation Angle | **-15.000** | `rotation="-15"`: FCPXML counts degrees counter-clockwise; Resolve's Rotation Angle is expected to use the same convention (positive = counter-clockwise), so the value carries over unchanged. In ReCut the still is turned **15° clockwise** |
| Composite › Opacity | **70.00** | `adjust-blend amount="0.7"` |
| Cropping | all 0 | no crop in the project |

**Picture (the decisive check):** a 640×360 px yellow card (half the frame's width and height) over the red A_Red picture, slightly see-through, its red centre square at **x 832, y 252** px from the top-left of the 1280×720 frame (192 px right of and 108 px above the frame's centre crosshair), turned **clockwise** by 15°: the word "TOP" and the card's top edge slope **down to the right** (the right end is lower).
- If the Inspector shows **+15** but the picture is turned clockwise, Resolve's sign convention is the opposite of what we assumed: mark F13 NOTE (not FAIL) and give both.
- If the picture is turned **counter-clockwise** (top edge slopes up to the right), that is a FAIL whatever the number says.
- If Position shows 26.666667 / 15 instead of 192 / 108, or the card is not where described, that is a FAIL (unit mismatch): give the observed values.
- The fit to the frame depends on Project Settings › Image Scaling › Input Scaling = "Scale entire image to fit" (Resolve's default). If it was different, say so.

### F14 V2 keyframed clip
- D_Purple.mp4 on V2, 00:00:05:00–00:00:08:00, Source In 00:00:01:00 (frame 24), no audio clip of its own in ReCut (from FCPXML its sound comes in at −96 dB, silent: expected, see F4).
- Position X keyframes **-320 at 00:00:05:00** → **+320 at 00:00:07:00**, then held to the clip's end (Resolve may show a third keyframe at the clip's end, 00:00:08:00, with the same value). Position Y stays 0.
- Zoom keyframes **0.400 at 00:00:05:00** → **0.600 at 00:00:07:00**, then held. Interpolation linear.
- Values at the playhead: at 00:00:05:00 X = -320, Zoom = 0.4; at 00:00:06:00 X = 0, Zoom = 0.5; at 00:00:07:00 X = 320, Zoom = 0.6. Picture: a small purple picture moving left → right across the blue one, growing as it moves.

### F15 Compound clip
- The ReCut compound clip arrives flattened (expected): **V3** D_Purple.mp4 00:00:11:00–00:00:13:00, Source In 00:00:13:12 (frame 324), full frame (it covers V1); its D_Purple.mp4 sound over the same range and source, **once** (A3 in ReCut; from FCPXML on whichever audio track Resolve picks, linked to the V3 picture).

### F16 Audio not doubled
- Exactly the audio items listed in F4, each once at its time (6 audible items plus the 2 silent extras). Two audible copies of the same file over the same time range is a FAIL. In the first run (kit v1) Resolve doubled the audio because it ignores FCPXML's `srcEnable`; kit v2 writes linked pairs as one clip instead.

### F18 Music
- Music_Pulse.wav (A2 in ReCut; from FCPXML on whichever audio track Resolve picks), 00:00:00:00–00:00:11:00: clip **Volume −6 dB** (Inspector › Audio › Volume), **fade in 24 frames** (1 s, to 00:00:01:00) and **fade out 48 frames** (2 s, from 00:00:09:00), visible as fade handles / a ramp on the clip.

### F19 Markers
- **Marker One** at 00:00:01:06: marker, default colour (FCPXML has no marker colours), note "on A_Red".
- **Chapter Two** at 00:00:04:04, 24 frames long: chapter marker (FCPXML `chapter-marker`), default colour (FCPXML has no marker colours).
- FCPXML puts markers on the clip under them (here the V1 clips), so Resolve may show them as **clip markers** on the V1 clip rather than on the timeline ruler. Either is fine: say where they appear. A chapter marker may arrive as a normal marker.

### Not carried by FCPXML (from the export's own report)
- **Transferred in another form:** 2 nested clips were flattened into their source clips.
- **Transferred in another form:** 1 fade from or to black is exported as an opacity fade.
- **Transferred in another form:** 1 Dip to Black transition is exported as opacity fades on the two clips.
- **Transferred in another form:** 1 audio crossfade of linked clips takes the length of the video dissolve on the same cut.
- **Transferred in another form:** 2 clips using only the picture or the sound of a file are written with the other half muted or transparent.
- **Transferred in another form:** FCPXML has no marker colours: 2 markers import in the default colour.

---

## OpenTimelineIO — `exports/Resolve Test.otio`

Same timeline, tracks, clips, record and source ranges as FCPXML. What differs is listed per check. OTIO import needs Resolve 18.5 or later.

### O3 Timeline
- Name "Resolve Test", 23.976 fps, 360 frames (00:00:15:00); the OTIO's global start time is 00:00:00:00.

### O4 Tracks
| Resolve track | ReCut track (after flattening) | Clips | Files, in order | Note |
|---|---|---|---|---|
| V1 | V1 | 5 | A_Red.mp4, B_Blue.mp4, C_Green.mp4, A_Red.mp4, B_Blue.mp4 (disabled) |  |
| V2 | V2 | 2 | V2_Still.png, D_Purple.mp4 |  |
| V3 | V2 (2) | 1 | D_Purple.mp4 | contents of the compound clip |
| A1 | A1 | 4 | A_Red.mp4, B_Blue.mp4, C_Green.mp4, A_Red.mp4 |  |
| A2 | A2 | 1 | Music_Pulse.wav |  |
| A3 | A2 (2) | 1 | D_Purple.mp4 | contents of the compound clip |

### O5 / O6 Clips
| # | Track | File | Record In | Record Out | Frames | Source In (= burned-in label on the clip's first frame) | Speed | Enabled | Burned-in label check (park the playhead here) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | V1 | A_Red.mp4 | 00:00:00:00 | 00:00:03:00 | 72 | 00:00:02:00 (frame 48) | 100% | yes | at **00:00:00:12** → FRAME **0060**, TC 00:00:02:12 |
| 2 | V1 | B_Blue.mp4 | 00:00:04:00 | 00:00:08:00 | 96 | 00:00:05:00 (frame 120) | 100% | yes | at **00:00:04:00** → FRAME **0120**, TC 00:00:05:00 |
| 3 | V1 | C_Green.mp4 | 00:00:08:00 | 00:00:11:00 | 72 | 00:00:10:00 (frame 240) | 200% | yes | at **00:00:08:12** → FRAME **0264**, TC 00:00:11:00 |
| 4 | V1 | A_Red.mp4 | 00:00:11:00 | 00:00:14:00 | 72 | 00:00:12:12 (frame 300) | 100% | yes | at **00:00:13:00** → FRAME **0348**, TC 00:00:14:12 |
| 5 | V1 | B_Blue.mp4 | 00:00:14:00 | 00:00:15:00 | 24 | 00:00:16:16 (frame 400) | 100% | **no** | disabled: viewer shows what is below it (black) |
| 6 | V2 | V2_Still.png | 00:00:01:00 | 00:00:03:00 | 48 | — | — | yes | still image (no label) |
| 7 | V2 | D_Purple.mp4 | 00:00:05:00 | 00:00:08:00 | 72 | 00:00:01:00 (frame 24) | 100% | yes | at **00:00:05:00** → FRAME **0024**, TC 00:00:01:00 |
| 8 | V3 | D_Purple.mp4 | 00:00:11:00 | 00:00:13:00 | 48 | 00:00:13:12 (frame 324) | 100% | yes | at **00:00:11:00** → FRAME **0324**, TC 00:00:13:12 |
| 9 | A1 | A_Red.mp4 | 00:00:00:00 | 00:00:03:00 | 72 | 00:00:02:00 (frame 48) | 100% | yes | (audio) |
| 10 | A1 | B_Blue.mp4 | 00:00:04:00 | 00:00:08:00 | 96 | 00:00:05:00 (frame 120) | 100% | yes | (audio) |
| 11 | A1 | C_Green.mp4 | 00:00:08:00 | 00:00:11:00 | 72 | 00:00:10:00 (frame 240) | 200% | yes | (audio) |
| 12 | A1 | A_Red.mp4 | 00:00:11:00 | 00:00:14:00 | 72 | 00:00:12:12 (frame 300) | 100% | yes | (audio) |
| 13 | A2 | Music_Pulse.wav | 00:00:00:00 | 00:00:11:00 | 264 | 00:00:00:00 (frame 0) | 100% | yes | (audio) |
| 14 | A3 | D_Purple.mp4 | 00:00:11:00 | 00:00:13:00 | 48 | 00:00:13:12 (frame 324) | 100% | yes | (audio) |

### O7 Gap
- As F7: V1 empty from 00:00:03:00 to 00:00:04:00.

### O8–O10, O17 Transitions
- V1: **fade from black**, 12 frames, 00:00:00:00 to 00:00:00:12 on A_Red.mp4, as a 12-frame transition from the empty track (a dissolve from black) at the start of the clip. Viewer: 00:00:00:00 is black, 00:00:00:06 is about half brightness, 00:00:00:12 is full brightness.
- V1: **Cross Dissolve**, 24 frames, centred on the cut at 00:00:08:00 (from 00:00:07:12 to 00:00:08:12), B_Blue.mp4 → C_Green.mp4.
- V1: **Dip to Black**, 12 frames centred on the cut at 00:00:11:00, C_Green.mp4 → A_Red.mp4, **as a plain cut** (OTIO has no Dip to Black; this is expected, see "Not carried").
- A1: **Audio cross fade**, 12 frames, centred on the cut at 00:00:08:00 (from 00:00:07:18 to 00:00:08:06), B_Blue.mp4 → C_Green.mp4.

### O11 Speed, O12 disabled clip
- As F11 (200%; OTIO `LinearTimeWarp` with time_scalar 2) and F12 (disabled clip, `enabled: false`).

### O13 V2 still — expected **without** its transform
- OTIO has no standard transform: V2_Still.png on V2 (00:00:01:00–00:00:03:00) is expected **full frame, centred, not rotated, 100% opacity** (Inspector: Zoom 1, Position 0/0, Rotation 0, Opacity 100). ReCut keeps the values only in metadata other tools ignore. If Resolve does apply a transform, that is a surprise: NOTE it with the values.

### O14 V2 keyframed clip — expected **without** animation
- D_Purple.mp4 on V2 00:00:05:00–00:00:08:00, full frame, no keyframes (it covers the blue clip below it).

### O15 Compound clip, O16 audio not doubled
- As F15 and F16 (V3 / A3, one audio copy per clip).

### O18 Music — expected **without** level and fades
- Music_Pulse.wav on A2, 00:00:00:00–00:00:11:00, at 0 dB with no fades (OTIO carries no levels or fades).

### O19 Markers
- **Marker One** at 00:00:01:06: marker, colour Red, note "on A_Red".
- **Chapter Two** at 00:00:04:04, 24 frames long: plain marker (was a chapter marker in ReCut), colour Blue.
- These are timeline markers (on the ruler).

### Not carried by OTIO (from the export's own report)
- **Lost or approximated:** OTIO has no Dip to Black: 1 dip is exported as a cut.
- **Lost or approximated:** Position and scale of 2 clips: kept only as ReCut metadata, which other editors ignore.
- **Lost or approximated:** Rotation of 1 clip: kept only as ReCut metadata, which other editors ignore.
- **Lost or approximated:** Opacity of 1 clip: kept only as ReCut metadata, which other editors ignore.
- **Lost or approximated:** Keyframes of 1 clip: kept only as ReCut metadata, which other editors ignore.
- **Lost or approximated:** Audio levels and fades of 1 clip: kept only as ReCut metadata, which other editors ignore.
- **Transferred in another form:** 2 nested clips were flattened into their source clips.
- **Transferred in another form:** 1 chapter marker is exported as a plain marker.
- **Transferred in another form:** Linked video and audio are exported as separate clips (10 clips); the link is kept as ReCut metadata.

---

## EDL — `exports/Resolve Test_V1.edl`, `exports/Resolve Test_V2.edl`, `exports/Resolve Test_V3.edl`

One EDL per video track; each imports as its own timeline with one video track (V1) and the audio that rides on its events. Reel names are `AX`; the `* SOURCE FILE:` lines carry the full path, `* FROM CLIP NAME:` the file name.

A CMX dissolve starts at its event's record in, so Resolve may show the **cut point** of a dissolve at the dissolve's start (e.g. 00:00:07:12) instead of its centre (00:00:08:00). Either is fine as long as the dissolve spans the same frames and the check frames show the expected labels.

### E2 / E3 `Resolve Test_V1.edl` (V1) clips
| # | Track | File | Record In | Record Out | Frames | Source In (= burned-in label on the clip's first frame) | Speed | Enabled | Burned-in label check (park the playhead here) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | V1 | A_Red.mp4 | 00:00:00:00 | 00:00:03:00 | 72 | 00:00:02:00 (frame 48) | 100% | yes | at **00:00:00:12** → FRAME **0060**, TC 00:00:02:12 |
| 2 | V1 | B_Blue.mp4 | 00:00:04:00 | 00:00:08:00 | 96 | 00:00:05:00 (frame 120) | 100% | yes | at **00:00:04:00** → FRAME **0120**, TC 00:00:05:00 |
| 3 | V1 | C_Green.mp4 | 00:00:08:00 | 00:00:11:00 | 72 | 00:00:10:00 (frame 240) | 200% | yes | at **00:00:08:12** → FRAME **0264**, TC 00:00:11:00 |
| 4 | V1 | A_Red.mp4 | 00:00:11:00 | 00:00:14:00 | 72 | 00:00:12:12 (frame 300) | 100% | yes | at **00:00:11:06** → FRAME **0306**, TC 00:00:12:18 |
- Audio: each of these events carries channel A1 (`B` = picture + A1), so A1 gets 4 clips under them with the same ranges (E9). No other audio (the music, the compound clip's audio) is in this EDL.

The EDL itself, for reference:

```
TITLE: Resolve Test V1
FCM: NON-DROP FRAME

001  BL       V     C        00:00:00:00 00:00:00:00 00:00:00:00 00:00:00:00
001  AX       B     D    012 00:00:02:00 00:00:05:00 00:00:00:00 00:00:03:00
* TO CLIP NAME: A_Red.mp4
* SOURCE FILE: /RECUT_KIT_ROOT/media/A_Red.mp4
* LOC: 00:00:01:06 RED     Marker One
002  AX       B     C        00:00:05:00 00:00:08:12 00:00:04:00 00:00:07:12
* FROM CLIP NAME: B_Blue.mp4
* SOURCE FILE: /RECUT_KIT_ROOT/media/B_Blue.mp4
* LOC: 00:00:04:04 BLUE    Chapter Two
003  AX       B     C        00:00:08:12 00:00:08:12 00:00:07:12 00:00:07:12
003  AX       B     D    024 00:00:09:00 00:00:15:12 00:00:07:12 00:00:10:18
M2   AX       048.0                00:00:09:00
* FROM CLIP NAME: B_Blue.mp4
* TO CLIP NAME: C_Green.mp4
* SOURCE FILE: /RECUT_KIT_ROOT/media/C_Green.mp4
004  AX       B     C        00:00:15:12 00:00:15:12 00:00:10:18 00:00:10:18
004  BL       V     D    006 00:00:00:00 00:00:00:06 00:00:10:18 00:00:11:00
* FROM CLIP NAME: C_Green.mp4
005  BL       V     C        00:00:00:00 00:00:00:00 00:00:11:00 00:00:11:00
005  AX       B     D    006 00:00:12:12 00:00:15:12 00:00:11:00 00:00:14:00
* TO CLIP NAME: A_Red.mp4
* SOURCE FILE: /RECUT_KIT_ROOT/media/A_Red.mp4
```

### E4–E7 transitions and speed
- V1: **fade from black**, 12 frames, 00:00:00:00 to 00:00:00:12 on A_Red.mp4, as a dissolve from black (reel BL) at the start of the clip. Viewer: 00:00:00:00 is black, 00:00:00:06 is about half brightness, 00:00:00:12 is full brightness.
- V1: **Cross Dissolve**, 24 frames, centred on the cut at 00:00:08:00 (from 00:00:07:12 to 00:00:08:12), B_Blue.mp4 → C_Green.mp4.
- V1: **Dip to Black**, 12 frames centred on the cut at 00:00:11:00, C_Green.mp4 → A_Red.mp4, as a dissolve to black (6 frames, 00:00:10:18–00:00:11:00) and a dissolve from black (6 frames, 00:00:11:00–00:00:11:06). Viewer: the frame at 00:00:11:00 is black.
- C_Green.mp4: `M2` line with 048.0 fps (= 200% of 23.976): speed 200%, labels as in F11 (at 00:00:08:12 FRAME 264, at 00:00:09:00 FRAME 288).

### E8 Disabled clip
- B_Blue.mp4 (disabled in ReCut) is **not** in the EDL: the V1 timeline ends at 00:00:14:00.

### E10 Markers
- `* LOC:` line: **Marker One** at 00:00:01:06, Red.
- `* LOC:` line: **Chapter Two** at 00:00:04:04, Blue.
- Resolve may or may not turn `LOC` comments into markers on EDL import: report what you see (NOTE if none).

### E11 `Resolve Test_V2.edl` (V2)
| # | Track | File | Record In | Record Out | Frames | Source In (= burned-in label on the clip's first frame) | Speed | Enabled | Burned-in label check (park the playhead here) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | V1 | V2_Still.png | 00:00:01:00 | 00:00:03:00 | 48 | — | — | yes | still image (no label) |
| 2 | V1 | D_Purple.mp4 | 00:00:05:00 | 00:00:08:00 | 72 | 00:00:01:00 (frame 24) | 100% | yes | at **00:00:05:00** → FRAME **0024**, TC 00:00:01:00 |
- Resolve 21 starts an EDL timeline at its first event's record timecode: this timeline starts at **00:00:01:00** (expected; the record timecodes in the table are unchanged). Take readings at the record timecodes as listed.
- Both full frame, no transform, no animation, no audio. The still is listed with source timecode 00:00:00:00–00:00:02:00; Resolve may need it relinked by hand or may refuse it: NOTE what happens.

```
TITLE: Resolve Test V2
FCM: NON-DROP FRAME

001  AX       V     C        00:00:00:00 00:00:02:00 00:00:01:00 00:00:03:00
* FROM CLIP NAME: V2_Still.png
* SOURCE FILE: /RECUT_KIT_ROOT/media/V2_Still.png
* LOC: 00:00:01:06 RED     Marker One
002  AX       V     C        00:00:01:00 00:00:04:00 00:00:05:00 00:00:08:00
* FROM CLIP NAME: D_Purple.mp4
* SOURCE FILE: /RECUT_KIT_ROOT/media/D_Purple.mp4
```

### E12 `Resolve Test_V3.edl` (V3, compound clip contents)
| # | Track | File | Record In | Record Out | Frames | Source In (= burned-in label on the clip's first frame) | Speed | Enabled | Burned-in label check (park the playhead here) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | V1 | D_Purple.mp4 | 00:00:11:00 | 00:00:13:00 | 48 | 00:00:13:12 (frame 324) | 100% | yes | at **00:00:11:00** → FRAME **0324**, TC 00:00:13:12 |
- The timeline starts at **00:00:11:00** (its first event; expected in Resolve 21).
- Its audio rides on the event as channel 3 (`AUD  3`): Resolve may put it on A3 or A1, or leave it out; note which.

```
TITLE: Resolve Test V3
FCM: NON-DROP FRAME

001  AX       V     C        00:00:13:12 00:00:15:12 00:00:11:00 00:00:13:00
AUD  3
* FROM CLIP NAME: D_Purple.mp4
* SOURCE FILE: /RECUT_KIT_ROOT/media/D_Purple.mp4
```

### Not carried by EDL (from the export's own report)
- **Lost or approximated:** 1 audio clip not linked to a video clip with the same in and out points is not in the EDL.
- **Lost or approximated:** 1 audio crossfade or fade is not in the EDL.
- **Lost or approximated:** 1 disabled clip is left out of the EDL.
- **Lost or approximated:** Position and scale of 2 clips: not in the EDL.
- **Lost or approximated:** Rotation of 1 clip: not in the EDL.
- **Lost or approximated:** Opacity of 1 clip: not in the EDL.
- **Lost or approximated:** Keyframes of 1 clip: not in the EDL.
- **Transferred in another form:** 2 nested clips were flattened into their source clips.
- **Transferred in another form:** Audio on 3 events with a dissolve or fade dissolves with the picture in the EDL.
- **Transferred in another form:** Speed changes on 1 clip are M2 motion effects; check their timing after import.
- **Transferred in another form:** 1 still image is listed as a clip from 00:00:00:00; check it after relinking.

---

## Optional: 29.97 drop-frame sequence "Resolve Test DF" (D1–D3)

`exports/Resolve Test DF.fcpxml`, `exports/Resolve Test DF.otio`, `exports/Resolve Test DF_V1.edl`. 1280×720, **29.97 fps drop-frame** (timecode written with `;` before the frames), 2090 frames = 00:01:09;22. Drop-frame timecode skips the labels ;00 and ;01 at the start of every minute except every tenth, so record frame 1800 is **00:01:00;02**, not 00:01:00;00.

| Resolve track | ReCut track (after flattening) | Clips | Files, in order | Note |
|---|---|---|---|---|
| V1 | V1 | 2 | E_NTSC_2997.mp4, E_NTSC_2997.mp4 |  |
| A1 | A1 | 2 | E_NTSC_2997.mp4, E_NTSC_2997.mp4 |  |

| # | Track | File | Record In | Record Out | Frames | Source In (= burned-in label on the clip's first frame) | Speed | Enabled | Burned-in label check (park the playhead here) |
|---|---|---|---|---|---|---|---|---|---|
| 1 | V1 | E_NTSC_2997.mp4 | 00:00:00;00 | 00:00:59;20 | 1790 | 00:00:00;05 (frame 5) | 100% | yes | at **00:00:00;00** → FRAME **0005**, TC 00:00:00;05 |
| 2 | V1 | E_NTSC_2997.mp4 | 00:00:59;20 | 00:01:09;22 | 300 | 00:00:04;00 (frame 120) | 100% | yes | at **00:01:00;07** → FRAME **0135**, TC 00:00:04;15 |
| 3 | A1 | E_NTSC_2997.mp4 | 00:00:00;00 | 00:00:59;20 | 1790 | 00:00:00;05 (frame 5) | 100% | yes | (audio) |
| 4 | A1 | E_NTSC_2997.mp4 | 00:00:59;20 | 00:01:09;22 | 300 | 00:00:04;00 (frame 120) | 100% | yes | (audio) |

- V1: **Cross Dissolve**, 30 frames, centred on the cut at 00:00:59;20 (from 00:00:59;05 to 00:01:00;07), E_NTSC_2997.mp4 → E_NTSC_2997.mp4.
- **One minute** at 00:01:00;02: marker, colour Cyan or Green.
- The burned-in TC label in E_NTSC_2997.mp4 is drop-frame too (e.g. FRAME 1802 shows TC 00:01:00;04).

Known Resolve 21 behaviour: the OTIO comes in as **non-drop-frame** timecode even in a drop-frame project (OTIO has no drop-frame flag): every frame is in place, but timecodes show `:` and count 30 per second (the marker at frame 1800 shows 00:01:00:00). That is a NOTE for D2, not a FAIL, if the frames are right.

Not carried: FCPXML — FCPXML has no marker colours: 1 marker imports in the default colour. OTIO — Linked video and audio are exported as separate clips (4 clips); the link is kept as ReCut metadata. EDL — Audio on 1 event with a dissolve or fade dissolves with the picture in the EDL.

---

## Optional Part B: what ReCut's Export Timeline dialog should report

The dialog's report line and lists must match these (they come from the same code):

| Sequence | Format | Report line | Files written (default name) |
|---|---|---|---|
| Resolve Test | FCPXML | 14 clips · 3 video tracks, 3 audio tracks · 00:00:15:00 · 6 media files | Resolve Test.fcpxml |
| Resolve Test | OTIO | 14 clips · 3 video tracks, 3 audio tracks · 00:00:15:00 · 6 media files | Resolve Test.otio |
| Resolve Test | EDL | 14 clips · 3 video tracks, 3 audio tracks · 00:00:15:00 · 6 media files · 3 files | Resolve Test_V1.edl, Resolve Test_V2.edl, Resolve Test_V3.edl |
| Resolve Test DF | FCPXML | 4 clips · 1 video track, 1 audio track · 00:01:09;22 · 1 media file | Resolve Test DF.fcpxml |
| Resolve Test DF | OTIO | 4 clips · 1 video track, 1 audio track · 00:01:09;22 · 1 media file | Resolve Test DF.otio |
| Resolve Test DF | EDL | 4 clips · 1 video track, 1 audio track · 00:01:09;22 · 1 media file | Resolve Test DF_V1.edl |

The issue lists for "Resolve Test" are the "Not carried" lists above (warnings under "Lost or approximated", infos under "Transferred in another form").
