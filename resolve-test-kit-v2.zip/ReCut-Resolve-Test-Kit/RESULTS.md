# RESULTS — ReCut timeline export into DaVinci Resolve

Fill in every row. **PASS**: matches EXPECTED.md. **FAIL**: differs (say exactly how: expected vs observed). **NOTE**: matches the "Not carried" list, or a difference you are unsure about. **SKIP**: not done (say why). Put screenshot file names (in `screenshots/`) in the Observed column.

## Environment

| Item | Value |
|---|---|
| DaVinci Resolve version (DaVinci Resolve › About DaVinci Resolve) | |
| Resolve edition (free / Studio) | |
| macOS version (Apple menu › About This Mac) | |
| Mac chip (Apple M1/M2/M3/M4… or Intel) | |
| Kit folder path | |
| Date | |
| Who ran it (human / agent name) | |

## Setup

| Id | Check | Result (PASS / FAIL / NOTE / SKIP) | Observed (values, what differs, screenshot file names) |
|---|---|---|---|
| S1 | localize.sh output | | |
| S2 | Resolve project settings used | | |

## Part A1 — FCPXML (`exports/Resolve Test.fcpxml`)

| Id | Check | Result (PASS / FAIL / NOTE / SKIP) | Observed (values, what differs, screenshot file names) |
|---|---|---|---|
| F1 | Import completes (note every dialog and warning) | | |
| F2 | All media online, media pool content | | |
| F3 | Timeline format and start timecode | | |
| F4 | Track list | | |
| F5 | Record In / Out of every clip | | |
| F6 | Source In and burned-in labels | | |
| F7 | Gap on V1 | | |
| F8 | Fade from black at the start | | |
| F9 | Cross Dissolve on V1 | | |
| F10 | Dip to Black | | |
| F11 | 200% speed clip | | |
| F12 | Disabled clip | | |
| F13 | V2 still: Inspector values and picture | | |
| F14 | V2 keyframed clip | | |
| F15 | Compound clip flattened | | |
| F16 | Audio not doubled | | |
| F17 | Audio cross fade on A1 | | |
| F18 | Music level and fades on A2 | | |
| F19 | Markers | | |
| F20 | Plays through | | |

## Part A2 — OpenTimelineIO (`exports/Resolve Test.otio`)

| Id | Check | Result (PASS / FAIL / NOTE / SKIP) | Observed (values, what differs, screenshot file names) |
|---|---|---|---|
| O1 | Import completes (note every dialog and warning) | | |
| O2 | All media online, media pool content | | |
| O3 | Timeline format and start timecode | | |
| O4 | Track list | | |
| O5 | Record In / Out of every clip | | |
| O6 | Source In and burned-in labels | | |
| O7 | Gap on V1 | | |
| O8 | Fade from black at the start | | |
| O9 | Cross Dissolve on V1 | | |
| O10 | Dip to Black | | |
| O11 | 200% speed clip | | |
| O12 | Disabled clip | | |
| O13 | V2 still (no transform expected) | | |
| O14 | V2 clip (no animation expected) | | |
| O15 | Compound clip flattened | | |
| O16 | Audio not doubled | | |
| O17 | Audio cross fade on A1 | | |
| O18 | Music on A2 (no level or fades expected) | | |
| O19 | Markers | | |
| O20 | Plays through | | |

## Part A3 — EDL (`exports/Resolve Test_V1.edl`, `exports/Resolve Test_V2.edl`, `exports/Resolve Test_V3.edl`)

| Id | Check | Result (PASS / FAIL / NOTE / SKIP) | Observed (values, what differs, screenshot file names) |
|---|---|---|---|
| E1 | Import of _V1.edl and how the media linked | | |
| E2 | V1 events: Record In / Out | | |
| E3 | V1 Source In and burned-in labels | | |
| E4 | Fade from black at the start | | |
| E5 | Cross Dissolve | | |
| E6 | Dip to Black (two dissolves via black) | | |
| E7 | 200% speed (M2) | | |
| E8 | Disabled clip left out | | |
| E9 | Audio on A1, music absent | | |
| E10 | Markers (LOC lines) | | |
| E11 | _V2.edl: still and D_Purple clip | | |
| E12 | _V3.edl: compound clip content | | |

## Optional — 29.97 drop-frame (`exports/Resolve Test DF.*`)

| Id | Check | Result (PASS / FAIL / NOTE / SKIP) | Observed (values, what differs, screenshot file names) |
|---|---|---|---|
| D1 | FCPXML at 29.97 drop-frame | | |
| D2 | OTIO at 29.97 drop-frame | | |
| D3 | EDL at 29.97 drop-frame | | |

## Optional Part B — ReCut app

| Id | Check | Result (PASS / FAIL / NOTE / SKIP) | Observed (values, what differs, screenshot file names) |
|---|---|---|---|
| B1 | Install and start ReCut | | |
| B2 | Open the project (media online) | | |
| B3 | Export Timeline: FCPXML report and files | | |
| B4 | Export Timeline: OTIO report and files | | |
| B5 | Export Timeline: EDL report and files | | |
| B6 | App exports identical to the kit's | | |
| B7 | App-exported FCPXML into Resolve | | |

## Anything else

(Error messages verbatim, crashes, anything surprising, suggestions.)
