ReCut Resolve test kit: synthetic media, a ReCut project and its FCPXML / OTIO / EDL timeline exports, to check that they import correctly into DaVinci Resolve.
Kit v2. Re-test after the first Resolve run: start with RETEST.md. Full test: start with INSTRUCTIONS.md (setup: unzip to ~/Desktop/ReCut-Resolve-Test-Kit, run "sh localize.sh"); expected values are in EXPECTED.md, fill in RESULTS.md.
Credits: all media (colour cards, tones, still) was generated with FFmpeg for this test; no third-party content.
