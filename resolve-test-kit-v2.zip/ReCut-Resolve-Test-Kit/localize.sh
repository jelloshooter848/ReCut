#!/bin/sh
# ReCut Resolve test kit: point the timeline files and the ReCut project at this folder.
#
# The files in exports/ and project/ were written with the placeholder folder /RECUT_KIT_ROOT. This script replaces
# it with the absolute path of the folder this script is in:
#   - as a file URL (file:///Users/you/...; spaces and other characters percent-encoded) in .fcpxml and .otio files,
#   - as a plain path in .edl files and the .recut project.
# The first run keeps the original files in _originals/; every run starts from them, so it is safe to run again
# (for example after moving the folder). POSIX sh, sed, awk and od only (macOS and Linux).
#
# Usage:  sh localize.sh
set -eu

PH=/RECUT_KIT_ROOT
cd "$(dirname "$0")"
KIT=$(pwd)

case "$KIT" in
  *'"'* | *'\'* | *'
'*) echo "localize.sh: the folder path contains a quote, backslash or line break; move the kit to a simpler path" >&2; exit 1 ;;
esac
case "$KIT" in
  *' '*) echo "localize.sh: note: the folder path contains spaces; this works, but a path without spaces is recommended" ;;
esac

# Percent-encode a path for a file URL, byte by byte, like JavaScript's encodeURIComponent on each path segment
# (letters, digits and - _ . ! ~ * ' ( ) are kept, '/' separates segments, everything else becomes %XX).
urlpath() {
  printf '%s' "$1" | LC_ALL=C od -An -v -tx1 | LC_ALL=C awk -v sq="'" '
    BEGIN {
      for (i = 0; i < 256; i++) code[sprintf("%02x", i)] = i
      keep = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.!~*()/" sq
    }
    { for (k = 1; k <= NF; k++) {
        c = code[$k]; ch = (c >= 32 && c < 127) ? sprintf("%c", c) : ""
        if (ch != "" && index(keep, ch) > 0) printf "%s", ch; else printf "%%%s", toupper($k)
    } }'
}

# Escape a string for the replacement side of sed s|...|...|.
sedrepl() { printf '%s' "$1" | sed -e 's/[\\&|]/\\&/g'; }

URL_ROOT=$(sedrepl "file://$(urlpath "$KIT")")
PLAIN_ROOT=$(sedrepl "$KIT")

# Keep the originals once.
if [ ! -d _originals ]; then
  mkdir -p _originals
  cp -R exports _originals/exports
  cp -R project _originals/project
fi

n=0
for src in _originals/exports/* _originals/project/*; do
  [ -f "$src" ] || continue
  dst=${src#_originals/}
  case "$src" in
    *.fcpxml | *.otio) sed -e "s|file://$PH/|$URL_ROOT/|g" -e "s|$PH/|$PLAIN_ROOT/|g" "$src" > "$dst.tmp" ;;
    *) sed -e "s|$PH/|$PLAIN_ROOT/|g" "$src" > "$dst.tmp" ;;
  esac
  mv "$dst.tmp" "$dst"
  n=$((n + 1))
done

if grep -l "$PH" exports/* project/* >/dev/null 2>&1; then
  echo "localize.sh: FAILED: the placeholder is still in: $(grep -l "$PH" exports/* project/* | tr '\n' ' ')" >&2
  exit 1
fi

missing=0
for f in A_Red.mp4 B_Blue.mp4 C_Green.mp4 D_Purple.mp4 E_NTSC_2997.mp4 Music_Pulse.wav V2_Still.png; do
  if [ -f "media/$f" ]; then echo "  found   $KIT/media/$f"; else echo "  MISSING $KIT/media/$f" >&2; missing=1; fi
done
[ "$missing" = 0 ] || { echo "localize.sh: FAILED: media files are missing (re-extract the kit)" >&2; exit 1; }

mkdir -p screenshots
echo "localize.sh: rewrote $n files to point at $KIT"
echo "  example URL: file://$(urlpath "$KIT")/media/A_Red.mp4"
echo "localize.sh: OK"
